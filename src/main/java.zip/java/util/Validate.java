package util;

public class Validate {

}
