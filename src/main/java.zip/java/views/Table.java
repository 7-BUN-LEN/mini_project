package views;

public class Table {
}
